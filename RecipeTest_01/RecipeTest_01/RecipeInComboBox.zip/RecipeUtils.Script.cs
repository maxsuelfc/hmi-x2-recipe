//--------------------------------------------------------------
// Press F1 to get help about using script.
// To access an object that is not located in the current class, start the call with Globals.
// When using events and timers be cautious not to generate memoryleaks,
// please see the help for more information.
//---------------------------------------------------------------

/*
*******************************************************************
All examples in this support document are only intended
to improve understanding of the functionality and 
handling of the equipment. 
Beijer Electronics Incorporated cannot assume any liability if these
examples are used in real applications.
In view of the wide range of applications for this 
equipment, users must acquire sufficient knowledge 
themselves in order to ensure that it is correctly used in 
their specific application. Persons responsible for the 
application and the equipment must themselves 
ensure that each application is in compliance with all 
relevant requirements, standards and legislation in 
respect to configuration and safety.
Beijer Electronics Incorporated will accept no liability for any 
damage incurred during the installation or use of this 
equipment.
Beijer Electronics Incorporated prohibits all modification, changes
or conversion of the equipment.

This sample has dependencies to internal iX-functions. It has been 
tested with version 2.xx. There are no guarantees that this sample 
will compile or work as intended in future versions of iX since the 
internal architecture may be changed.
*******************************************************************
*/

namespace Neo.ApplicationFramework.Generated
{
	using System.Windows.Forms;
	using System;
	using System.Drawing;
	using Neo.ApplicationFramework.Tools;
	using Neo.ApplicationFramework.Common.Graphics.Logic;
	using Neo.ApplicationFramework.Controls;
	using Neo.ApplicationFramework.Interfaces;
	//Added by programmer
	using Neo.ApplicationFramework.Controls.WindowsControls;
	using System.Data;
	using System.Data.SqlServerCe;
	using System.IO;
	using System.Reflection;
	using System.Collections.Generic;

    
	public partial class RecipeUtils
	{
		
		/// <summary>
		/// Member variable to hold a sql connection.
		/// </summary>
		private SqlCeConnection m_SqlConnection;
		

		/// <summary>
		/// GetRecipeNamesInTable
		/// Pass in Table-name and a an array.
		/// Method will extract all the "FieldNames" i.e Recipe names in the table given 
		/// and will resize the array to fit a dynamic number of recipes.
		/// </summary>
		/// <param name="TableName">Pass in the table-name</param>
		/// <param name="RecipeNames">Refrence to the array which willbe populated with recipe names avaliable</param>
		/// <returns>void</returns>
		public void GetRecipesNamesInTable(string TableName, ref List<string> RecipeNames)
		{	
			//Creates a dataset to contain the answer from the sql-server
			DataSet resultSet = new DataSet();
			//Gets the data from the table
			resultSet = this.GetResultSet(TableName);
			//Populate the array with resultSet data			
			foreach (DataRow row in resultSet.Tables[0].Rows)
			{
				RecipeNames.Add(row.ItemArray[0].ToString());
			}	
		}	

		///<summary>
		/// Get the path to where the project is excecuting.
		/// This differs if you run the project from the pc
		/// or in the terminal.
		/// </summary>
		private string ExcecutingPath
		{
			get { return Path.GetDirectoryName(Assembly.GetExecutingAssembly().ManifestModule.FullyQualifiedName); }
		}

		/// <summary>
		/// Tries to fetch a DataSet from the database.
		/// </summary>
		/// <param name="tableName">The name of the table.</param>
		/// <returns>DataSet containing all the data from the table.</returns>
		private DataSet GetResultSet(string tableName)
		{
			// Variable to hold the data.
			DataSet dataSet = null;
			// Call a method that tries to connect to the database.
			if (ConnectToDataBase())
			{
				// Using try/catch to prevent a crash, should anything go wrong.
				try
				{
					// This is the sql command to excecute. Fetch all data from the given table.
					string sqlString = string.Format("SELECT * FROM {0} ORDER BY FieldName ASC" , tableName);
					// Create a data adapter to excecute the query and fetch the data.
					// It uses the connection variable.
					SqlCeDataAdapter sqlCeDataAdapter = new SqlCeDataAdapter(sqlString, m_SqlConnection);
					// Initialize the DataSet that is used to hold the result.
					dataSet = new DataSet();
					// Populate the DataSet with the result from the data adapter.
					sqlCeDataAdapter.Fill(dataSet);
				}
				catch (SqlCeException)
				{
					// Catches any exceptions from the database and prevents the 
					// program from terminating unexpectedly.
				}
			}
			
			// Disconnects from the database.
			// This is very important.
			// If you leave connections open, there can be unexpected behaviour,
			// like locks and crashes. There is also a memory cost for every open
			// connection.
			DisconnectFromDataBase();

			// Return the result.
			return dataSet;
		}

		/// <summary>
		/// Tries to connect to the database.
		/// </summary>
		/// <returns>True if successful, otherwise false.</returns>
		private bool ConnectToDataBase()
		{
			// Checks if there already is an active connection. 
			// If so, it returns true right away.
			if (m_SqlConnection != null && m_SqlConnection.State == ConnectionState.Open)
				return true;

			// Create a new sql connection object.
			m_SqlConnection = new SqlCeConnection();
			// Specify the connectionstring, with the full path to the database.
			m_SqlConnection.ConnectionString = string.Format("data source={0}", Path.Combine(ExcecutingPath, "Database.sdf"));

			// Using a try/catch in case something goes wrong.
			// Should the full path to the database be wrong, it will throw an exception.
			// This prevents the termination of the program.
			try 
			{
				// Tries to open the connection.
				m_SqlConnection.Open();
			}
			catch (SqlCeException)
			{
				// If it went wrong, terminate the connection completely.
				DisconnectFromDataBase();
				// Return false to indicate that the connection couldn't be made.
				return false;
			}

			// Checks the state of the connection, returning true if it is open.
			return m_SqlConnection.State == ConnectionState.Open;
		}

		/// <summary>
		/// Disconnects from the database and disposes the connection.
		/// </summary>
		private void DisconnectFromDataBase()
		{
			// Makes sure that the connection isn't already disposed.
			if (m_SqlConnection != null)
			{
				// Checks to see if the connection is open.
				if(m_SqlConnection.State == ConnectionState.Open)
				{
					// Close the connection.
					m_SqlConnection.Close();
				}
				// Dispose the connection object.
				m_SqlConnection.Dispose();
				// Set it to null, so that it is easy to find out
				// if it is in use or not.
				m_SqlConnection = null;
			}
		}

	}
}
