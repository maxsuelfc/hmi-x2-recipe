//--------------------------------------------------------------
// Press F1 to get help about using script.
// To access an object that is not located in the current class, start the call with Globals.
// When using events and timers be cautious not to generate memoryleaks,
// please see the help for more information.
//---------------------------------------------------------------

/*
	*******************************************************************
	All examples in this support document are only intended
	to improve understanding of the functionality and 
	handling of the equipment. 
	Beijer Electronics Inc. cannot assume any liability if these
	examples are used in real applications.
	In view of the wide range of applications for this 
	equipment, users must acquire sufficient knowledge 
	themselves in order to ensure that it is correctly used in 
	their specific application. Persons responsible for the 
	application and the equipment must themselves 
	ensure that each application is in compliance with all 
	relevant requirements, standards and legislation in 
	respect to configuration and safety.
	Beijer Electronics Inc. will accept no liability for any 
	damage incurred during the installation or use of this 
	equipment.
	Beijer Electronics Inc. prohibits all modification, changes
	or conversion of the equipment.
	*******************************************************************
*/

namespace Neo.ApplicationFramework.Generated
{
    using System.Windows.Forms;
    using System;
    using System.Drawing;
    using Neo.ApplicationFramework.Tools;
    using Neo.ApplicationFramework.Common.Graphics.Logic;
    using Neo.ApplicationFramework.Controls;
    using Neo.ApplicationFramework.Interfaces;
	//Added by programmer
	using System.Collections.Generic;
	using System.Globalization;
	using System.Threading;
    
    
    public partial class RecipeData
    {
		
		
		
		
//		public static GlobalDataItem GetGlobalDataItem(string propertyName) 
//		{ 
//			PropertyInfo tagProperty = typeof(Neo.ApplicationFramework.Generated.Tags).GetProperty(propertyName); 
//			if(recipeProperty == null) 
//				return null; 
//			else 
//				return recipeProperty.GetValue(Globals.Recipe1, null) as GlobalDataItem; 
//		}
		
		void RecipeData_Opened(System.Object sender, System.EventArgs e)
		{
			//Clear and get current items from list
			ComboBox.Items.Clear();
			//Create list to hold the recipe names
			List <string> recipeNames = new List<string>();
			//Get recipe names from the database
						
			Globals.RecipeUtils.GetRecipesNamesInTable("Theater", ref recipeNames);
			//sort the recipe names
			recipeNames.Sort();
			//Bind the list of recipes to the combobox
			foreach (string s in recipeNames)
				ComboBox.Items.Add(s);
			//ComboBox.ItemSource = recipeNames;
		}
		
		void ComboBox_SelectionChanged(System.Object sender, System.EventArgs e)
		{
			Globals.Theater.LoadRecipe(ComboBox.Text.ToString());
		}
    }
}
